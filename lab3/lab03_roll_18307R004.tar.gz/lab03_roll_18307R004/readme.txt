Name: S Divakar Bhat
Roll Number: 18307R004


___Acknowledgements___

1.https://plus.maths.org/content/real-projective-plane-homogeneous-coordinates
2.https://plus.maths.org/content/projective-geometry-projective-plane-geometry
3.http://robotics.stanford.edu/~birch/projective/node4.html

___Honor Code___

	I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.

	S Divakar Bhat (18307R004)


